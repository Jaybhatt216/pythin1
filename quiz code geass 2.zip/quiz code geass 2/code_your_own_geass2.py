
blanks = ["___1___", "___2___", "___3___", "___4___"]

easy_paragraph = '''___1___ is anime about ___2___ and his black knights waging war against ___3___ to obtain ___4___ and aid lelouch in his plans for his ideal world'''
medium_paragraph = '''lelouch has many friends such as  ___1___, and the ace piolt of the black knights ___2___ the loyal code orange  ___3___ and of course the immortal witch  ___4___.''' 
hard_paragraph = '''lelouch has many weapons at his dispoal such as the  ___1___ and ___2___,his hidden ability is the power to  ___3___ into beliving his way is correct and of course  the  ___4___, with a powerful defense'''

easy_answers = ["code geass", "lelouch", "birtiana", "freedom"]
medium_answers = ["suzaku", "kallen", "jerimiah", "cc"]
hard_answers = ["Geass", "intelligence", "inspire people", "giant mech"]	



def greeting(player_name):

		
	print "Hello Anime watcher " + player_name  


def get_setup(level): 
	

	if level == "1":
		print "\nYou chose level 1 - Easy.\n"
		return easy_paragraph, easy_answers

	elif level == "2":
		print "\nYou chose level 2 - Medium.\n"
		return medium_paragraph, medium_answers

	else: # For level 3.
		print "\nYou chose level 3 - Hard.\n"
		return hard_paragraph, hard_answers


def word_in_blanks(word, blanks):


	for blank in blanks: 
		if blank in word: 
			return blank
	return None


def replace_the_blank(word, replaced, blanks, user_answer, index): 
	

	if word_in_blanks(word, blanks) == None:
		if word not in replaced:
			replaced.append(word)
	else:
		replacement = word_in_blanks(word, blanks)
		word = word.replace(replacement, user_answer.upper())

		if replacement == blanks[index]:
			if replacement not in replaced:
				replaced.append(word)
			else:
				position = replaced.index(replacement)
				replaced[position] = word
		else:
			replaced.append(replacement)

	return replaced


def fill_in_answers(paragraph, blanks, replaced, user_answer, index): 
	
	split_paragraph = paragraph.split()

	if type(replaced) == str:
		replaced = replaced.split()		

	for word in split_paragraph:
		replace_the_blank(word, replaced, blanks, user_answer, index)
		
	replaced = " ".join(replaced)
	head, sep, tail = replaced.partition() 
	replaced = head + sep
	return replaced


def collect_answers(level, paragraph, answers):
	
	replaced = []
	user_answer = ""

	index = 0
	for blank in blanks:
		
		question = "\n state your answer for " + blank + "?"
		print question
		user_answer = raw_input("Type here: ")
		user_answer = user_answer.lower()

		while user_answer != answers[index]:
			print "\n you fail "
			user_answer = raw_input()
			user_answer = user_answer.lower()

		print "\n that is true\n"	
									
		replaced = fill_in_answers(paragraph, blanks, replaced, user_answer, index)
		print replaced			

		index += 1
	
	return replaced, index



def play_game():
	

	player_name = raw_input("State thy name")
	greeting(player_name)

	level = raw_input("\nEasy - 1 | Medium - 2 | Hard - 3 | ")

	if level == "1" or level == "2" or level == "3":
		paragraph, answers = get_setup(level)     
		print paragraph 

		replaced = collect_answers(level, paragraph, answers)

		print "\nYAY, " + player_name + ", YOU KNOW ANIME!\n"	
	
	else:		
		print "\nWRONG! Please pick an actual level, " + player_name + ". Game will now restart.\n"
		play_game()

play_game() 
